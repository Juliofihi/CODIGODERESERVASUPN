# ReservaUPN V4: finalización automática e historial

## Qué cambió

1. Las reservas por horas en estado `Pendiente`, `Confirmada` o `En uso` pasan a `Finalizada` cuando termina su horario.
2. Los préstamos de libros pasan a `Finalizada` al cumplirse su plazo. Ejemplo: préstamo de 3 días desde el lunes: termina el jueves a las 00:00.
3. Las reservas `Cancelada` y `Rechazada` no se modifican automáticamente.
4. Cada finalización automática queda anotada una sola vez en la tabla existente `historial`.
5. Las reservas finalizadas NO se borran de SQLite ni de los reportes Excel. Están en la subpestaña `Historial` de `Mis reservas` o `Reservas`.
6. La subpestaña `Vigentes` muestra reservas pendientes, confirmadas o en uso. El catálogo muestra la disponibilidad según el reloj.
7. Las comprobaciones se realizan al ejecutar `python menu.py`, cuando se consultan recursos o reservas y cada minuto mientras la ventana está abierta. Con el programa cerrado no corre ninguna tarea; al volver a abrir, se actualiza lo que haya vencido.

## Cómo conservar lo que ya tienes en la V3

El ZIP contiene una copia de la base original del proyecto (40 recursos, sin tus cuentas creadas localmente).

1. Conserva tu carpeta V3 y, antes de mover nada, haz copia de `ReservaUPN/base_datos/reservaupn.db`.
2. Extrae la V4 en una carpeta diferente.
3. Copia **el reservaupn.db de tu V3** a `ReservaUPN/base_datos/` dentro de la V4 y reemplaza solamente la base incluida.
4. Abre la nueva carpeta `ReservaUPN` en Visual Studio Code.
5. Inicia con `python menu.py`. El sistema conservará los usuarios y reservas que tenga tu base V3.

## Pruebas

Desde la carpeta del proyecto:

    python -m unittest discover -s pruebas -v

Las pruebas utilizan archivos temporales y no modifican el archivo real `base_datos/reservaupn.db`.

## Ejemplo rápido

- Computadora: 11:00 a 12:00 -> desde las 12:00 queda `Finalizada` y puede volver a reservarse.
- Libro: desde el día 4 al día 7 -> el día 7 finaliza; no el mismo día 4.
- La vista `Vigentes` queda sin esas reservas, pero podrás encontrarlas en `Historial` y en el reporte Excel.

**Nota:** la V3 proporcionada usa Tkinter (ventanas). Esta V4 conserva esa interfaz y agrega únicamente las funciones de vencimiento e historial. No reemplaza el programa por una versión de consola.
