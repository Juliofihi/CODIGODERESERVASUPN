"""Pruebas de finalización e historial. Nunca altera la base original."""
import os
import shutil
import tempfile
import unittest
from datetime import date, datetime, timedelta

import database
import reservas


class VencimientosPruebas(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.original = database.RUTA_BASE_DATOS
        cls.temporal = tempfile.TemporaryDirectory(prefix='prueba_vencimientos_')
        cls.copia = os.path.join(cls.temporal.name, 'reservaupn.db')
        shutil.copy2(cls.original, cls.copia)
        database.RUTA_BASE_DATOS = cls.copia
        database.preparar_base_datos()
        cls.codigo = 'N00999999'
        conexion = database.conectar_base_datos()
        try:
            conexion.execute('''INSERT OR IGNORE INTO estudiantes
                (codigo_estudiante, nombres, apellidos, correo, contrasena_hash, estado)
                VALUES (?, 'Estudiante', 'Prueba', 'prueba_v4@upn.pe', 'hashprueba', 'Activo')''',
                (cls.codigo,))
            conexion.commit()
        finally:
            conexion.close()

    @classmethod
    def tearDownClass(cls):
        database.RUTA_BASE_DATOS = cls.original
        cls.temporal.cleanup()

    def nuevo(self, codigo_recurso, inicio, fin, hora_inicio, hora_fin, estado):
        conexion = database.conectar_base_datos()
        try:
            id_recurso = conexion.execute('SELECT id_recurso FROM recursos WHERE codigo_inventario = ?',
                                          (codigo_recurso,)).fetchone()[0]
            cursor = conexion.execute('''INSERT INTO reservas
                (codigo_estudiante, id_recurso, fecha_inicio, fecha_fin, hora_inicio, hora_fin, estado)
                VALUES (?, ?, ?, ?, ?, ?, ?)''',
                (self.codigo, id_recurso, inicio, fin, hora_inicio, hora_fin, estado))
            conexion.commit()
            return cursor.lastrowid
        finally:
            conexion.close()

    def estado(self, id_reserva):
        conexion = database.conectar_base_datos()
        try:
            return conexion.execute('SELECT estado FROM reservas WHERE id_reserva = ?',
                                    (id_reserva,)).fetchone()[0]
        finally:
            conexion.close()

    def test_01_reservas_expiradas_y_futuras(self):
        hoy = date.today() + timedelta(days=20)
        ayer = (hoy - timedelta(days=1)).isoformat()
        dia = hoy.isoformat()
        manana = (hoy + timedelta(days=1)).isoformat()
        simulacion = datetime.combine(hoy, datetime.strptime('16:00', '%H:%M').time())
        vencida_ayer = self.nuevo('PC-004', ayer, ayer, '09:00', '10:00', 'Pendiente')
        vencida_hoy = self.nuevo('PC-005', dia, dia, '14:00', '15:00', 'En uso')
        justo_fin = self.nuevo('PC-006', dia, dia, '15:00', '16:00', 'Confirmada')
        vigente = self.nuevo('PC-007', dia, dia, '15:30', '16:30', 'Confirmada')
        futura = self.nuevo('PC-008', manana, manana, '11:00', '12:00', 'Pendiente')
        libro_vencido = self.nuevo('LIB-004', (hoy-timedelta(days=3)).isoformat(), dia,
                                  None, None, 'Confirmada')
        libro_vigente = self.nuevo('LIB-005', (hoy-timedelta(days=1)).isoformat(),
                                  (hoy+timedelta(days=2)).isoformat(), None, None, 'Pendiente')
        cancelada = self.nuevo('PC-009', ayer, ayer, '13:00', '14:00', 'Cancelada')

        # Antes del cierre, una reserva hasta las 16:00 sigue vigente.
        self.assertEqual(reservas.finalizar_reservas_vencidas(simulacion - timedelta(minutes=1)), 3)
        self.assertEqual(self.estado(justo_fin), 'Confirmada')
        self.assertEqual(self.estado(libro_vencido), 'Finalizada')
        self.assertEqual(self.estado(vencida_ayer), 'Finalizada')

        # A las 16:00 exactas, finaliza la reserva cuyo final es 16:00.
        self.assertEqual(reservas.finalizar_reservas_vencidas(simulacion), 1)
        for item in (vencida_ayer, vencida_hoy, justo_fin, libro_vencido):
            self.assertEqual(self.estado(item), 'Finalizada')
        for item in (vigente, futura, libro_vigente):
            self.assertIn(self.estado(item), ('Pendiente', 'Confirmada'))
        self.assertEqual(self.estado(cancelada), 'Cancelada')

        # Repetir el procedimiento no vuelve a escribir cambios ni eventos.
        self.assertEqual(reservas.finalizar_reservas_vencidas(simulacion), 0)
        conexion = database.conectar_base_datos()
        try:
            for item in (vencida_ayer, vencida_hoy, justo_fin, libro_vencido):
                self.assertEqual(conexion.execute('''SELECT COUNT(*) FROM historial
                    WHERE accion = 'Reserva finalizada automáticamente' AND descripcion = ?''',
                    ('Reserva N.° '+str(item),)).fetchone()[0], 1)
            # No hay DELETE: todos los registros permanecen almacenados.
            ids = [vencida_ayer, vencida_hoy, justo_fin, vigente, futura,
                   libro_vencido, libro_vigente, cancelada]
            self.assertEqual(conexion.execute('SELECT COUNT(*) FROM reservas WHERE id_reserva IN (' +
                                              ','.join('?' for _ in ids) + ')', ids).fetchone()[0], 8)
        finally:
            conexion.close()

    def test_02_fechas_de_libro_son_tres_dias(self):
        inicio = date.today() + timedelta(days=40)
        fin = inicio + timedelta(days=3)
        libro = self.nuevo('LIB-006', inicio.isoformat(), fin.isoformat(), None, None, 'Pendiente')
        antes = datetime.combine(fin-timedelta(days=1), datetime.strptime('23:59','%H:%M').time())
        reservas.finalizar_reservas_vencidas(antes)
        self.assertEqual(self.estado(libro), 'Pendiente')
        despues = datetime.combine(fin, datetime.strptime('00:00','%H:%M').time())
        self.assertGreaterEqual(reservas.finalizar_reservas_vencidas(despues), 1)
        self.assertEqual(self.estado(libro), 'Finalizada')

    def test_03_consultar_actualiza_vencimientos_reales(self):
        pasado = (date.today() - timedelta(days=2)).isoformat()
        r = self.nuevo('PC-010', pasado, pasado, '09:00','10:00','Confirmada')
        # Cualquier consulta de estudiante debe actualizar los estados vencidos.
        resultados = reservas.consultar_reservas_estudiante(self.codigo)
        actual = next(fila for fila in resultados if fila['id_reserva'] == r)
        self.assertEqual(actual['estado'], 'Finalizada')
        self.assertEqual(self.estado(r), 'Finalizada')


if __name__ == '__main__':
    unittest.main()
