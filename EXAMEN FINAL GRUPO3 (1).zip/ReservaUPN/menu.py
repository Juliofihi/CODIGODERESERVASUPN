"""Punto de inicio del sistema: ejecutar 'python menu.py'."""
from database import preparar_base_datos
from interfaz import iniciar_interfaz
from reservas import finalizar_reservas_vencidas


if __name__ == '__main__':
    preparar_base_datos()
    finalizar_reservas_vencidas()
    iniciar_interfaz()
